const schedule = require('node-schedule')
const ConnectionsState = require('./agentLogic/connectionsState')

//(AmmonBurgi) Rule for running the scheduled job every 24 hours.
const ruleForDTA = new schedule.RecurrenceRule()
ruleForDTA.hour = 0;
ruleForDTA.minute = 0;

// Use for testing...run job every 30 seconds
// ruleForDTA.second = new schedule.Range(0, 59, 30)

//(AmmonBurgi) Clean up the connections state keys (dtc_dta_presentation) table. Remove records that are older than 24 hours.
schedule.scheduleJob(ruleForDTA, async () => {
  try {
    console.log('Job is running at', new Date())

    await ConnectionsState.removeConnectionStatesOlderThanHours(
      'dtc_dta_presentation',
      24,
    )
  } catch (error) {
    console.error('Error during schedule job (DTA Flow): ', error)
  }
})

process.on('uncaughtException', (err) => {
  console.log('Uncaught exception while running job: ', err.message)
})
