const crypto = require('crypto')
const {DTC} = require('sita-dtc')
const {imageConversion} = require('jp2-to-jpeg')
const {DateTime} = require('luxon')

const AdminAPI = require('../adminAPI')
const Websockets = require('../websockets')

const Connections = require('./connections')

const ContactsCompiled = require('../orm/contactsCompiled')
const Presentations = require('../orm/presentations')

const Axios = require('axios')

const deleteAgentPresentation = async (presentation_exchange_id) => {
  try {
    const result = await AdminAPI.Presentations.deletePresentation(
      presentation_exchange_id,
    )

    return result
  } catch (error) {
    console.error(
      'Error deleting presentation by presentation_exchanged_id: ',
      error,
    )
  }
}

const requestSchemaPresentation = async (
  connection_id,
  schema_attributes,
  schema_id,
) => {
  console.log(`Requesting Presentation from Connection: ${connection_id}`)

  return await AdminAPI.Presentations.requestPresentationBySchemaId(
    connection_id,
    schema_attributes,
    schema_id,
    'Requesting Presentation',
    false,
  )
}

const requestSelfAttestedPresentation = async (
  connectionID,
  attributes,
  comment,
  trace,
) => {
  try {
    console.log(
      `Requesting Self-Attested Presentation from Connection: ${connectionID}`,
    )

    return await AdminAPI.Presentations.requestProof(
      connectionID,
      attributes,
      comment,
      trace,
    )
  } catch (error) {
    console.log('Request for Self-Attested Presentation Failed: ', error)
  }
}

const verifyDTC = async (dtc) => {
  try {
    let decodedDTC = new DTC({base64: dtc})
    decodedDTC = new DTC(decodedDTC.dtcDataProps)

    const response = await Axios({
      method: 'POST',
      url: process.env.PKD_API,
      data: {
        DTC: dtc,
      },
      headers: {
        Authorization: process.env.PKD_API_AUTHORIZATION,
        'Content-Type': 'application/json',
      },
    })

    const trustValue = response.data.TrustLevel

    //TODO: Handle all TrustLevel cases
    switch (trustValue) {
      case '1':
        console.log(`DTC verified - (${trustValue})`)

        const mrzData = decodedDTC.mrzData
        const issuerData = decodedDTC.issuerData
        const jpgPhoto = imageConversion(decodedDTC.photo)

        function generateUPK(data) {
          try {
            if (
              data.documentNumber &&
              data.issuingState &&
              data.dateOfBirth &&
              data.dateOfExpiry
            ) {
              let currentYear = new Date().getFullYear()
              currentYear = currentYear.toString().slice(-2)

              const yearOfBirth = data.dateOfBirth.toString().slice(0, 2)
              let dateOfBirth = data.dateOfBirth.toString()

              if (currentYear < yearOfBirth) {
                dateOfBirth = '19' + dateOfBirth
              } else {
                dateOfBirth = '20' + dateOfBirth
              }

              // (AmmonBurgi) Format date of birth and date of expiry to YYYY-MM-DD
              const formattedDateOfBirth = dateOfBirth.replace(
                /(\d{4})(\d{2})(\d{2})/g,
                '$1-$2-$3',
              )

              const dateOfExpiry = '20' + data.dateOfExpiry.toString()
              const formattedDateOfExpiry = dateOfExpiry.replace(
                /(\d{4})(\d{2})(\d{2})/g,
                '$1-$2-$3',
              )

              const concatenatedFields = `${data.documentNumber}${data.issuingState}${formattedDateOfBirth}${formattedDateOfExpiry}`

              return crypto
                .createHash('md5')
                .update(concatenatedFields)
                .digest('hex')
            } else {
              throw 'Missing required fields for generating UPK'
            }
          } catch (error) {
            console.log('Error generating UPK: ', error)
          }
        }

        const givenNames = Array.isArray(mrzData.givenNames)
          ? mrzData.givenNames.join(' ')
          : mrzData.givenNames

        const verifiedDTCAttr = [
          {
            name: 'created-date',
            value: Math.round(
              DateTime.fromISO(new Date()).ts / 1000,
            ).toString(),
          },
          {
            name: 'date-of-birth',
            value: mrzData.dateOfBirth ? `${mrzData.dateOfBirth}` : '',
          },
          {
            name: 'document-number',
            value: mrzData.documentNumber ? mrzData.documentNumber : '',
          },
          {
            name: 'document-type',
            value: mrzData.documentCode ? mrzData.documentCode : '',
          },
          {
            name: 'dtc',
            value: dtc,
          },
          {
            name: 'expiry-date',
            value: mrzData.dateOfExpiry ? `${mrzData.dateOfExpiry}` : '',
          },
          {
            name: 'family-name',
            value: mrzData.lastName ? mrzData.lastName : '',
          },
          {
            name: 'gender',
            value: mrzData.sex ? mrzData.sex : '',
          },
          {
            name: 'given-names',
            value: givenNames ? givenNames : '',
          },
          {
            name: 'issue-date',
            value: issuerData.issueDate ? `${issuerData.issueDate}` : '',
          },
          {
            name: 'issuing-authority',
            value: issuerData.issueAuthority ? issuerData.issueAuthority : '',
          },
          {
            name: 'issuing-state',
            value: mrzData.issuingState ? mrzData.issuingState : '',
          },
          {
            name: 'nationality',
            value: mrzData.nationality ? mrzData.nationality : '',
          },
          {
            name: 'chip-photo',
            value: jpgPhoto ? jpgPhoto : '',
          },
          {
            name: 'upk',
            value: mrzData ? generateUPK(mrzData) : '',
          },
        ]

        return verifiedDTCAttr
      case '0':
        console.log(
          `TrustLevel: ${trustValue}, Message: ${response.data.VerifyMessage}`,
        )

        return []
      case '-1':
        console.log(
          `TrustLevel: ${trustValue}, Message: ${response.data.VerifyMessage}`,
        )

        return []
      case '-2':
        console.log(
          `TrustLevel: ${trustValue}, Message: ${response.data.VerifyMessage}`,
        )

        return []
      default:
        throw `The trust level was not recognized - (${trustValue})`
    }
  } catch (error) {
    console.error('Failed to check DTC: ', error)
  }
}

const adminMessage = async (message) => {
  if (message.state === 'verified') {
    let attributes = {}
    let requestedProof = {}
    if (message.presentation) {
      requestedProof = message.presentation.requested_proof
    } else if (message.by_format) {
      requestedProof = message.by_format.pres.indy.requested_proof
    } else {
      //We don't have a requested proof object
      throw new Error('Failed to build attributes object! No requested proof.')
    }

    for (const attributeObj in requestedProof) {
      const value = requestedProof[attributeObj]
      if (attributeObj === 'revealed_attrs') {
        console.log('revealed_attrs')
        for (const attribute in value) {
          attributes[attribute] = value[attribute].raw
        }
      } else if (attributeObj === 'self_attested_attrs') {
        console.log('self_attested_attrs')
        for (const attribute in value) {
          attributes[attribute] = value[attribute]
        }
      } else if (attributeObj === 'revealed_attr_groups') {
        console.log('revealed_attr_groups')
        for (const referent in value) {
          for (const attribute in value[referent].values) {
            attributes[attribute] = value[referent].values[attribute].raw
          }
        }
      } else {
        continue
      }
    }
    console.log('Verified Attributes: ', attributes)

    //(AmmonBurgi) Handle DTA/DTC flows
    try {
      const issueDTC = async () => {
        if (attributes.dtc) {
          let verifiedDTCAttributes = await verifyDTC(attributes.dtc)

          if (
            Array.isArray(verifiedDTCAttributes) &&
            verifiedDTCAttributes.length
          ) {
            const schemaDTC = process.env.SCHEMA_DTC_TYPE1_IDENTITY
            const schemaParts = schemaDTC.split(':')
            const dtcCredential = {
              connectionID: message.connection_id,
              schemaID: schemaDTC,
              schemaVersion: schemaParts[3],
              schemaName: schemaParts[2],
              schemaIssuerDID: schemaParts[0],
              comment: '',
              attributes: verifiedDTCAttributes,
            }

            await Credentials.autoIssueCredential(
              dtcCredential.connectionID,
              undefined,
              undefined,
              dtcCredential.schemaID,
              dtcCredential.schemaVersion,
              dtcCredential.schemaName,
              dtcCredential.schemaIssuerDID,
              dtcCredential.comment,
              dtcCredential.attributes,
            )
          }
        } else {
          console.log(
            'WARNING: Presentation does not belong to DTC or DTA flow!',
          )
        }
      }

      const connectionState = await ConnectionStates.getConnectionStatesByKey(
        message.connection_id,
        'dtc_dta_presentation',
      )
      if (connectionState) {
        const stateValues = connectionState.value
        console.log('StateValues: ', stateValues)

        if (
          stateValues.dtc.presentation_exchange_id ===
            message.presentation_exchange_id ||
          stateValues.dta.presentation_exchange_id ===
            message.presentation_exchange_id
        ) {
          let readyForIssuance = false
          let allVerifiedAttributes = {...attributes}

          //(AmmonBurgi) Find which presentation is being processed based on the presentation_exchange_id. Check to see if the other presentation has been verified. If so, then we can issue the DTA credential. If not, update the connection state values.
          if (
            stateValues.dtc.presentation_exchange_id ===
            message.presentation_exchange_id
          ) {
            if (stateValues.dta.verified === true) {
              readyForIssuance = true
              allVerifiedAttributes = {
                ...allVerifiedAttributes,
                ...stateValues.dta.verified_attributes,
              }
            } else {
              console.log('Update to verified DTC!')
              await ConnectionStates.updateOrCreateConnectionState(
                message.connection_id,
                'dtc_dta_presentation',
                {
                  ...stateValues,
                  dtc: {
                    presentation_exchange_id: message.presentation_exchange_id,
                    verified: true,
                    verified_attributes: attributes,
                  },
                },
              )
            }
          } else if (
            stateValues.dta.presentation_exchange_id ===
            message.presentation_exchange_id
          ) {
            if (stateValues.dtc.verified === true) {
              readyForIssuance = true
              allVerifiedAttributes = {
                ...allVerifiedAttributes,
                ...stateValues.dtc.verified_attributes,
              }
            } else {
              console.log('Update to verified DTA!')
              await ConnectionStates.updateOrCreateConnectionState(
                message.connection_id,
                'dtc_dta_presentation',
                {
                  ...stateValues,
                  dta: {
                    presentation_exchange_id: message.presentation_exchange_id,
                    verified: true,
                    verified_attributes: attributes,
                  },
                },
              )
            }
          }

          if (readyForIssuance) {
            // (AmmonBurgi) The DTA and DTC presentations have been verified and confirmed using the connection states. We should delete the connection state record, and issue the DTA credential.
            await ConnectionStates.removeConnectionStates(
              message.connection_id,
              'dtc_dta_presentation',
            )

            const organization = await Settings.getOrganization()
            const credentialIssueDate = Math.round(
              DateTime.fromISO(new Date()).ts / 1000,
            ).toString()

            const schemaDTA = process.env.SCHEMA_TRAVEL_AUTHORIZATION
            const schemaDTAParts = schemaDTA.split(':')
            const dtaCredential = {
              connectionID: message.connection_id,
              schemaID: schemaDTA,
              schemaVersion: schemaDTAParts[3],
              schemaName: schemaDTAParts[2],
              schemaIssuerDID: schemaDTAParts[0],
              comment: '',
              attributes: [
                {name: 'dta_number', value: allVerifiedAttributes.dta_number},
                {
                  name: 'dta_family_names',
                  value: allVerifiedAttributes.dta_family_names,
                },
                {
                  name: 'dta_given_names',
                  value: allVerifiedAttributes.dta_given_names,
                },
                {
                  name: 'dta_passport_number',
                  value: allVerifiedAttributes.dta_passport_number,
                },
                {
                  name: 'dta_date_of_birth',
                  value: allVerifiedAttributes.dta_date_of_birth,
                },
                {
                  name: 'dta_nationality',
                  value: allVerifiedAttributes.dta_nationality,
                },
                {name: 'dta_sex', value: allVerifiedAttributes.dta_sex},
                {name: 'dta_place_of_issue', value: 'Online'},
                {
                  name: 'dta_valid_from',
                  value: allVerifiedAttributes.dta_valid_from,
                },
                {
                  name: 'dta_valid_until',
                  value: allVerifiedAttributes.dta_valid_until,
                },
                {
                  name: 'dta_duration_of_stay',
                  value: allVerifiedAttributes.dta_duration_of_stay,
                },
                {
                  name: 'dta_number_of_entries',
                  value: allVerifiedAttributes.dta_number_of_entries,
                },
                {
                  name: 'dta_type/class/category',
                  value: allVerifiedAttributes['dta_type/class/category'],
                },
                {
                  name: 'dta_additional_information',
                  value: allVerifiedAttributes.dta_additional_information,
                },
                {
                  name: 'passport_issuing_state_or_organization',
                  value: allVerifiedAttributes['issuing-state'],
                },
                {
                  name: 'passport_expiration_date',
                  value: allVerifiedAttributes['expiry-date'],
                },
                {
                  name: 'passport_photo',
                  value: allVerifiedAttributes['chip-photo'],
                },
                {
                  name: 'document_image',
                  value: allVerifiedAttributes.document_image,
                },
                {name: 'document_assurance_level', value: '1'}, //(AmmonBurgi) Accepts values 1-4. Number 1 is for OCR only.
                {
                  name: 'document_issuing_state_or_organization',
                  value:
                    allVerifiedAttributes.document_issuing_state_or_organization,
                },
                {
                  name: 'credential_issuer_name',
                  value: organization.value.organizationName || '',
                },
                {
                  name: 'credential_issue_date_time',
                  value: credentialIssueDate,
                },
              ],
            }

            await Credentials.autoIssueCredential(
              dtaCredential.connectionID,
              undefined,
              undefined,
              dtaCredential.schemaID,
              dtaCredential.schemaVersion,
              dtaCredential.schemaName,
              dtaCredential.schemaIssuerDID,
              dtaCredential.comment,
              dtaCredential.attributes,
            )
          } else {
            console.log(
              'WARNING (DTA Issuance): Waiting on other presentations to be verified.',
            )
          }
        } else {
          //(AmmonBurgi) There is a connection state record for the DTA flow, but this presentation belongs to a different flow. Issue the DTC credential if it's a DTC presentation.
          console.log(
            'WARNING (DTA Issuance): Connection State record found but values do not much up with the current presentation_exchange_id!',
          )

          await issueDTC()
        }
      } else {
        console.log(
          'WARNING: No Connection State record found! Check for DTC flow.',
        )

        await issueDTC()
      }
    } catch (error) {
      console.error('Error while processing DTA/DTC flow: ', error)
    }
  } else if (message.state === null) {
    // (mikekebert) Send a basic message saying the verification failed for technical reasons
    console.log('Validation failed for technical reasons')
    await AdminAPI.Connections.sendBasicMessage(message.connection_id, {
      content: 'UNVERIFIED',
    })
  } else {
  }
}

const createPresentationReports = async (presentation) => {
  try {
    let contact

    const connection = await Connections.getConnection(
      presentation.connection_id,
    )
    if (connection && connection.contact_id) {
      contact = await ContactsCompiled.readContact(connection.contact_id)
    }

    console.log(presentation.connection_id)

    const presentationReport = await Presentations.createPresentationReports(
      presentation.presentation_exchange_id,
      presentation.trace,
      presentation.connection_id,
      presentation.role,
      presentation.created_at,
      presentation.updated_at,
      JSON.stringify(presentation.presentation_request_dict),
      presentation.initiator,
      JSON.stringify(presentation.presentation_request),
      presentation.state,
      presentation.thread_id,
      presentation.auto_present,
      JSON.stringify(presentation.presentation),
      contact ? contact.label : '',
      contact ? contact.contact_id : '',
    )

    // Broadcast the message to all connections
    Websockets.sendMessageToAll('PRESENTATIONS', 'PRESENTATION_REPORTS', {
      presentation_reports: [presentationReport],
    })
  } catch (error) {
    console.log('Error creating presentation reports:')
    throw error
  }
}

const updatePresentationReports = async (presentation) => {
  try {
    const contact = await Contacts.getContactByConnection(
      presentation.connection_id,
    )

    let presentationReport
    let presentationArg = [
      presentation.presentation_exchange_id,
      presentation.trace,
      presentation.connection_id,
      presentation.role,
      presentation.created_at,
      presentation.updated_at,
      JSON.stringify(presentation.presentation_request_dict),
      presentation.initiator,
      JSON.stringify(presentation.presentation_request),
      presentation.state,
      presentation.thread_id,
      presentation.auto_present,
      JSON.stringify(presentation.presentation),
      contact.label,
      contact.contact_id,
    ]

    // (AmmonBurgi) Remove the presentation from the arguments when updating, and delete the presentation stored in the ACA-PY agent
    if (process.env.STORE_PRESENTATION_ATTRIBUTES === 'false') {
      presentationArg[12] = undefined

      presentationReport = await Presentations.updatePresentationReports(
        ...presentationArg,
      )

      if (presentation.state === 'verified') {
        await deleteAgentPresentation(presentation.presentation_exchange_id)
      }
    } else {
      presentationReport = await Presentations.updatePresentationReports(
        ...presentationArg,
      )
    }

    // Broadcast the message to all connections
    Websockets.sendMessageToAll('PRESENTATIONS', 'PRESENTATION_REPORTS', {
      presentation_reports: [presentationReport],
    })
  } catch (error) {
    console.log('Error updating presentation reports:')
    throw error
  }
}

const getAll = async () => {
  try {
    console.log('Fetching presentation reports!')
    const presentationReports = await Presentations.readPresentations()

    return presentationReports
  } catch (error) {
    console.log('Error fetching presentation reports:')
    throw error
  }
}

module.exports = {
  adminMessage,
  createPresentationReports,
  deleteAgentPresentation,
  verifyDTC,
  updatePresentationReports,
  getAll,
  requestSchemaPresentation,
  requestSelfAttestedPresentation,
}

const ConnectionStates = require('./connectionsState')
const Contacts = require('./contacts')
const Credentials = require('./credentials')
const Settings = require('./settings')
