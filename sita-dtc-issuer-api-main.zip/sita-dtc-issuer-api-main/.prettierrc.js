module.exports = {
  bracketSpacing: false,
  jsxBracketSameLine: true,
  singleQuote: true,
  semi: false,
  trailingComma: 'all',
}
